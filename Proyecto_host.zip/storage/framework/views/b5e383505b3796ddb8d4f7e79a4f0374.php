<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Historial</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/estilosweb.css')); ?>">
</head>
<body>
<!-- inicio de navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('indexp')); ?>">
      <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" width="60" height="54">
    </a>
    <a class="navbar-brand" href="<?php echo e(route('indexp')); ?>">FreeSpace</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('explorar')); ?>">Explorar Espacios</a>
        </li>
      </ul>
      
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('reserva')); ?>">Reserva de Espacios</a>
        </li>
      </ul>
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link " href="<?php echo e(route('historial')); ?>">Historial de Reserva</a>
        </li>
      </ul>
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" href="<?php echo e(route('allRecervas')); ?>">Recervaciones</a>
        </li>
      </ul>
      <ul class="navbar-nav mb-2 mb-lg-0" style="margin-left: auto;">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('cerrarSesion')); ?>">Cerrar sesión</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--  final del navbar -->
<center>
  

  <h1>Todas las Recervaciones</h1>

</center>
<table class="table table-hover border border-5 border-success  table-bordered" >
  <thead>
      <tr>
          <th>Fecha de Registro</th>
          <th>Fecha a Utilizar</th>
          <th>Hora de Inicio</th>
          <th>Hora de Finalización</th>
          <th>Aula</th>
          <th>ID de Usuario</th>
      </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td><?php echo e($dato['fechaRegistro']); ?></td>
          <td><?php echo e($dato['fechaUtilizar']); ?></td>
          <td><?php echo e($dato['horaInicio']); ?></td>
          <td><?php echo e($dato['horaFinal']); ?></td>
          <td><?php echo e($dato['aula']); ?></td>
          <td><?php echo e($dato['idUsuario']); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


</body>
</html><?php /**PATH E:\Escuela\5 Cuatrimestre\Aplicaciones Web para I 4.0\proyecto\resources\views/profesores/allRecervas.blade.php ENDPATH**/ ?>