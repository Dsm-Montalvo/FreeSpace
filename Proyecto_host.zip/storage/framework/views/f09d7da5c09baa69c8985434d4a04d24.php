<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Detalles</title>
    <!-- Incluye Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/estilosweb.css')); ?>">
</head>
<body>
<!-- inicio de navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('indexe')); ?>">
      <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" width="60" height="54">
    </a>
    <a class="navbar-brand" href="<?php echo e(route('indexe')); ?>">FreeSpace</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('calendario')); ?>">Explorar Espacios</a>
        </li>
      </ul>
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active " href="<?php echo e(route('detalle')); ?>">Detalles de Espacios</a>
        </li>
      </ul>

      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('allRecervasE')); ?>">Recervaciones</a>
        </li>
      </ul>
      
      <ul class="navbar-nav mb-2 mb-lg-0" style="margin-left: auto;">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('cerrarSesion')); ?>">Cerrar sesión</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--  final del navbar -->
<center>

  <h1>Aula 103</h1>

</center>
<div style="width: 100%; display: flex; justify-content: space-between;">
  <div style="width: 30%; ">
      <canvas id="temperaturaChart" width="400" height="200"></canvas>
  </div>
  <div style="width: 30%;">
      <canvas id="humedadChart" width="400" height="200"></canvas>
  </div>
  <div style="width: 30%;">
      <canvas id="movimientoChart" width="400" height="200"></canvas>
  </div>
</div>

<br><br><hr>
<div >
<table class="table table-hover border border-2 border-success  table-bordered" >
  <thead>
      <tr>
          <th>Fecha de Registro</th>
          <th>Fecha a Utilizar</th>
          <th>Hora de Inicio</th>
          <th>Hora de Finalización</th>
          <th>Aula</th>
          <th>ID de Usuario</th>
      </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td><?php echo e($dato['fechaRegistro']); ?></td>
          <td><?php echo e($dato['fechaUtilizar']); ?></td>
          <td><?php echo e($dato['horaInicio']); ?></td>
          <td><?php echo e($dato['horaFinal']); ?></td>
          <td><?php echo e($dato['aula']); ?></td>
          <td><?php echo e($dato['idUsuario']); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>



<script>
  var temperaturaData = <?php echo json_encode($temperaturaData, 15, 512) ?>;
  var humedadData = <?php echo json_encode($humedadData, 15, 512) ?>;
  var movimientoData = <?php echo json_encode($movimientoData, 15, 512) ?>;

  var ctx1 = document.getElementById('temperaturaChart').getContext('2d');
  var temperaturaChart = new Chart(ctx1, {
      type: 'line',
      data: {
          labels: Array.from(Array(temperaturaData.length).keys()),
          datasets: [{
              label: 'Temperatura',
              data: temperaturaData,
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              borderColor: 'rgba(144, 45, 255, 1)',
              borderWidth: 1
          }]
      },
      options: {
        maintainAspectRatio: false,
        responsive: true,
        
      }
      
      
  });

  var ctx2 = document.getElementById('humedadChart').getContext('2d');
  var humedadChart = new Chart(ctx2, {
      type: 'line',
      data: {
          labels: Array.from(Array(humedadData.length).keys()),
          datasets: [{
              label: 'Humedad',
              data: humedadData,
              backgroundColor: 'rgba(144, 45, 255, 0.2)',
              borderColor: 'rgba(255, 255, 255, 1)',
              borderWidth: 1
          }]
      },
      options: {
        maintainAspectRatio: false,
        responsive: true,
      }
  });

  var ctx3 = document.getElementById('movimientoChart').getContext('2d');
  var movimientoChart = new Chart(ctx3, {
      type: 'bar',
      data: {
          labels: Array.from(Array(movimientoData.length).keys()),
          datasets: [{
              label: 'Movimiento',
              data: movimientoData,
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderColor: 'rgba(103, 246, 255, 1)',
              borderWidth: 1
          }]
      },
      options: {
        maintainAspectRatio: false,
        responsive: true,
        
      }
  });
</script>
</body>
</html><?php /**PATH E:\Escuela\5 Cuatrimestre\Aplicaciones Web para I 4.0\proyecto\resources\views/estudiantes/detalle3.blade.php ENDPATH**/ ?>