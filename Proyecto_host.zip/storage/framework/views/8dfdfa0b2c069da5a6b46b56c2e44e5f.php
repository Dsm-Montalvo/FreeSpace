<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosgraficas.css')); ?>">
    <title>Graficas</title>
</head>
<body>
    <section class="content">
        <h1>Datos de sensores</h1>
        <canvas id="myChart" height="300" width="300"></canvas>
    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.min.js" integrity="sha512-L0Shl7nXXzIlBSUUPpxrokqq4ojqgZFQczTYlGjzONGTDAcLremjwaWv5A+EDLnxhQzY5xUZPWLOLqYRkY0Cbw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html><?php /**PATH E:\Escuela\5 Cuatrimestre\Aplicaciones Web para I 4.0\proyecto\resources\views/grafico/graficas.blade.php ENDPATH**/ ?>