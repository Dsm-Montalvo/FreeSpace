<?php
    require_once resource_path('views/head/header.blade.php');
?>

<?php 
    require_once resource_path('views/head/footer.blade.php');
?><?php /**PATH E:\Escuela\5 Cuatrimestre\Aplicaciones Web para I 4.0\proyecto\resources\views/index.blade.php ENDPATH**/ ?>